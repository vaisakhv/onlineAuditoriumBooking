package com.ust_global.user;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import oracle.sql.DATE;

@SuppressWarnings("serial")
@Entity(name="SelectedEvents")
@Table(name="SelectedEvents")
public class Ticket implements Serializable
{
	
	/*
SQL> desc selectedEvents;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 TICKETNUMBER                              NOT NULL NUMBER(20)
 USERNAME                                           VARCHAR2(30)
 EVENTID                                            VARCHAR2(20)
 EVENTNAME                                          VARCHAR2(30)
 SELECTEDDATE                                       DATE
 SEATNUMBER                                         VARCHAR2(30)
 TICKETPRICE                                        NUMBER(10,2)
 NOOFSEATS                                          NUMBER
	*/
		private long ticketNumber;
		private String userName;
		private String eventId;
		private String eventName;
		private java.sql.Date selectedDate;
		private String seatNumber;
		private double ticketPrice;
		private int noOfSeats=1;
		
		
		public Ticket()
		{
			
		}
	
		@Id
//	    @SequenceGenerator( name = "appUsersSeq", sequenceName = "APP_USERS_SEQ", allocationSize = 1, initialValue = 1 )
//	    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "appUsersSeq" )
	    @Column( name = "TICKETNUMBER" )
	public long getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(long ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public java.sql.Date getSelectedDate() {
		return selectedDate;
	}

	public void setSelectedDate(java.sql.Date date) {
		this.selectedDate = date;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	
	
	
	
}
